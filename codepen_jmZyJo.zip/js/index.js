$(document).ready(function() {
  var randomQuote = "ABC";
  var randomAuthor = "ABC";
function newQuote(){
  var quotes = [
  {"quote": "\"Quality is not an act, it is a habit.\"", "author": "- Aristotle" },
  {"quote": "\"Geeks are people who love something so much that all the details matter.\"", "author": "- Melissa Meyer, Yahoo! CEO"},
  {"quote": "\"Be a yardstick of quality. Some people aren’t used to an environment where excellence is expected.\"", "author": "- Steve Jobs"
 },
  {"quote": "\"Good design adds value faster than it adds cost.\"", "author": "- Thomas C. Gale"},
 {"quote": "\"Quality means doing it right even when no one is looking.\"", "author": "- Henry Ford"},
    {"quote": "\"You can be a great tester if you have programming skills. You can also be a great tester if you have no programming skills at all. And, you can be a lousy tester with or without programming skills. A great tester will learn what skills she needs to continue to be great, in her own style.\"", "author": "-  Jerry Weinberg"},
    {"quote": "\"No amount of testing can prove a software right, a single test can prove a software wrong.\"", "author": "- Amir Ghahrai"},
    {"quote": "\"Discovering the unexpected is more important than confirming the known.\"", "author": "- George E. P. Box"},
    {"quote": "\"Testing is an infinite process of comparing the invisible to the ambiguous in order to avoid the unthinkable happening to the anonymous.\"", "author": "-  James Bach"},
    {"quote": "\"The more effort I put into testing the product conceptually at the start of the process, the less I effort I had to put into manually testing the product at the end because less bugs would emerge as a result.\"", "author": "- Trish Khoo"},
    {"quote": "\"Testers don’t break software, software is already broken.\"", "author": "- Amir Gahrai"},
    {"quote": "\"If we want to be serious about quality, it is time to get tired of finding bugs and start preventing their happening in the first place.\"", "author": "- Alan Page"},
    {"quote": "\"More than the act of testing, the act of designing tests is one of the best bug preventers known.\"", "author": "- Boris Beizer"},
    {"quote": "\"It’s hard enough to find an error in your code when you’re looking for it; it’s even harder when you’ve assumed your code is error-free.\"", "author": "- Steve McConnell"},
    {"quote": "\"Automation does not do what testers used to do, unless one ignores most things a tester really does. Automated testing is useful for extending the reach of the testers work, not to replace it.\"", "author": "- James Bach"},
    {"quote": "\"It’s automation, not automagic.\"", "author": "- Jim Hazen"},
    {"quote": "\"We have as many testers as we have developers. And testers spend all their time testing, and developers spend half their time testing. We’re more of a testing, a quality software organization than we’re a software organization.\"", "author": "- Bill Gates"},
    {"quote": "\"I remember the days when QA testers were treated almost as second-class citizens and developers ruled the software world. But as it recently occurred to me: we’re all testers now.\"", "author": "- Joe Colantonio"},
    {"quote": "\"Testing has to be an integral part of developing software and not a separate phase. When this approach is taken, product quality is owned by everyone on the team. It is easy to state, but hard to put into practice because of long-standing preconceived notions that developers and testers are better kept apart.\"", "author": "- James Sivak"}
];
//var bodyColor = blue;
var bodyColors =['LightPink', 'LavenderBlush', 'MistyRose', 'LightSteelBlue', 'Bisque', 'LightCyan', 'MistyRose'];

var randomNumber = Math.floor(Math.random() * (quotes.length))
var randomColor = Math.floor(Math.random() * (bodyColors.length));

document.body.style.backgroundColor=bodyColors[randomColor];
randomQuote = quotes[randomNumber].quote;
randomAuthor = quotes[randomNumber].author;
    
$(".quote").text(randomQuote);
$(".author").text(randomAuthor);  
}
  
  $(".btnNewQuote").on("click", function() {
    newQuote();
  });
  $(".btnTweet").on("click", function() {
  window.open('https://twitter.com/intent/tweet?text=' + randomQuote + randomAuthor);
  });
  
  
});